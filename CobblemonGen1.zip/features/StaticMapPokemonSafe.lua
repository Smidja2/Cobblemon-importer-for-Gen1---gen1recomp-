local mod=...
-- SAFE static Pokemon bridge:
-- 1) Never hide the vanilla NPC at content-load time.
-- 2) Create the Cobblemon actor first.
-- 3) Only after a valid actor exists, toggle the exact mapped object's sprite
--    to our transparent sprite definition for this session/map.
-- If actor creation/rendering fails, vanilla sprite remains visible.

local CELL=16
local actors={}
local hidden={}
local Voxel3D=nil
pcall(function()
 mod.content.sprites:register("SPRITE_COBBLEMON_NPC_SAFE_HIDDEN",{
  image=mod.assets:path("assets/cobblemon_hidden_npc_safe.png"),
  frames=1,walker=false,trueColor=true,frameWidth=16,frameHeight=16,anchorX=8,anchorY=16})
end)

local TARGETS={
 {map="ROUTE_12",dex=143,x=10,z=62},
 {map="ROUTE_16",dex=143,x=26,z=10},
 {map="POWER_PLANT",dex=145,x=4,z=9},
 {map="SEAFOAM_ISLANDS_B4F",dex=144,x=6,z=1},
 {map="VICTORY_ROAD_2F",dex=146,x=11,z=5},
 {map="CERULEAN_CAVE_B1F",dex=150,x=27,z=13},
}

local function imp()
 local a=mod.exports and (mod.exports.cobblemon_main or mod.exports.cobblemon_importer)
 if a and tonumber(a.api)==1 and type(a.createActor)=="function" then return a end
 if type(mod.find)=="function" then
  local ok,h=pcall(mod.find,"COBBLEMON_MAIN")
  if ok and h then
   a=h.exports and (h.exports.cobblemon_main or h.exports.cobblemon_importer)
   if a and tonumber(a.api)==1 and type(a.createActor)=="function" then return a end
  end
 end
end
local function companion()
 local a=mod.exports and mod.exports.voxel_companion
 local i=imp()
 if a and tonumber(a.api)==1 and type(a.register)=="function" then
  if i and type(i.Voxel3D)=="function" then local ok,v=pcall(i.Voxel3D);if ok then Voxel3D=v end end
  return a
 end
 if type(mod.find)=="function" then
  local ok,h=pcall(mod.find,"COBBLEMON_MAIN")
  if ok and h then
   a=h.exports and h.exports.voxel_companion
   local x=h.exports and (h.exports.cobblemon_main or h.exports.cobblemon_importer)
   if a and tonumber(a.api)==1 and type(a.register)=="function" then
    if x and type(x.Voxel3D)=="function" then local ok2,v=pcall(x.Voxel3D);if ok2 then Voxel3D=v end end
    return a
   end
  end
 end
end
local function key(map,t) return map..":"..tostring(t.index or (t.x..","..t.z)) end
local function liveAt(w,t)
 for _,e in ipairs((w and w.entities) or {}) do
  local x=tonumber(e and e.cellX)
  local z=tonumber(e and (e.cellY or e.cellZ))
  if x==t.x and z==t.z then return e end
 end
end
local function findTargetObject(mapId,t)
 if not (mod.world and mod.world.npc) then return nil end
 if t.index then
  local ok,h=pcall(function() return mod.world:npc(mapId,t.index) end)
  if ok then return h end
 end
 -- Fallback: find matching live NPC by exact cell through snapshot; its index/id
 -- remains vanilla. We do not remove it.
 return nil
end
local function makeActor(map,t,w)
 local k=key(map,t); if actors[k] then return actors[k] end
 local i=imp(); if not i then return nil end
 local y=(w.player and tonumber(w.player.y)) or 0
 local ok,a=pcall(i.createActor,t.dex,{manual=true,visible=false,x=t.x*CELL+8,y=y,z=t.z*CELL+8,yaw=0})
 if not ok or not a or not a.rig or not a.rig.parts or #a.rig.parts==0 then
  if a and a.destroy then pcall(function()a:destroy()end) end
  return nil
 end
 actors[k]=a
 return a
end
local function draw(a)
 if not (a and Voxel3D and type(Voxel3D.draw)=="function") then return false end
 local mat=a:matrix(); local drew=false
 for _,p in ipairs(a.rig.parts or {}) do
  if p.mesh and p.texture then
   local ok=pcall(Voxel3D.draw,p.mesh,p.texture,mat,0,mat)
   drew=drew or ok
  end
 end
 return drew
end
local function clear()
 for _,a in pairs(actors) do pcall(function()a:destroy()end) end
 actors={};hidden={}
end
local function discoverGen2(w)
 if not STATIC then return end
 -- Only accept live NPCs whose exposed species field identifies a known static Pokemon.
 for _,e in ipairs((w and w.entities) or {}) do
  local d=tonumber(e and (e.pokemon or e.species or e.wildSpecies or e.battleSpecies or e.dex))
  local x=tonumber(e and e.cellX);local z=tonumber(e and (e.cellY or e.cellZ))
  if d and STATIC[d] and x and z then
   local exists=false
   for _,t in ipairs(TARGETS) do if t.map==w.id and t.x==x and t.z==z then exists=true end end
   if not exists then TARGETS[#TARGETS+1]={map=w.id,dex=d,x=x,z=z,index=e.index} end
  end
 end
end

local c=companion()
if c then
 c.register({
  api=1,id="cobblemon.static_map_pokemon_safe",name="Cobblemon Static Map Pokemon Safe",version="0.2.0",
  priority=28,requires={"render_phases","world_snapshot"},optional={},
  worldChanged=clear,
  render={opaque_after_terrain=function(ctx)
   local w=ctx and ctx.world;if not (w and w.id) then return end
   discoverGen2(w)
   for _,t in ipairs(TARGETS) do
    if t.map==w.id then
     local e=liveAt(w,t)
     local k=key(w.id,t)
     if e then
      t.index=t.index or e.index
      local a=makeActor(w.id,t,w)
      if a then
       local y=(w.player and tonumber(w.player.y)) or 0
       a:setPosition(t.x*CELL+8,y,t.z*CELL+8);a:setAnimation("idle");a:setVisible(false)
       a:update((ctx.frame and ctx.frame.dt) or 1/60)
       local rendered=draw(a)
       -- Crucial safety gate: do not suppress vanilla until the 3D mesh actually drew.
       if rendered then hidden[k]=true end
      end
     else
      if actors[k] then pcall(function()actors[k]:destroy()end);actors[k]=nil end
      hidden[k]=nil
     end
    end
   end
  end},
  dispose=clear
 })
end
mod.exports.cobblemon_static_map_pokemon_safe={api=1,targets=TARGETS,hidden=hidden}
