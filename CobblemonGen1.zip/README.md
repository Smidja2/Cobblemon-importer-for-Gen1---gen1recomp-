CobblemonGen1

Cobblemon models and animations for the Gen1 recomp.

This build uses Cobblemon 1.8.1 + CCC 2.1 as external imports. The builder creates Cobblemon493Pack.zip so models, textures, rigs and animations for #001-493 are available for expanded-dex setups. Models and ecology accept #001-493 when those species exist in the active game/mod setup; unavailable species are ignored by the game data.

Battle:
- Keeps the Gen1 Cobblemon 3D battle integration.
- Uses the authored Cobblemon battle animations where available.
- Pokemon use their authored faint animation instead of simply disappearing at HP 0.
- Cry and attack animation support are kept.
- This does not use the heavily modified Gen2 battle presenter.

Overworld:
- Ground ecology.
- Flying ecology.
- Water ecology.
- Followers.
- Toon rendering support.
- Door/cave/warp follower fix: followers reset at the trainer when entering a real warp so they do not trail into black/out-of-map space.
- Seamless route connections keep the follower formation instead of treating every map change like a door warp.

Files needed to build:
1. Cobblemon 1.8.1 for Minecraft 1.21.1 / Fabric.
2. CCC 2.1 for Minecraft 1.21.1 / Data Pack. Download it as a .zip.

Open the HTML builder, select both files, then press BUILD.

The builder creates:
- Cobblemon493Pack.zip
- CobblemonGen1.zip

Install:
1. Import CobblemonGen1.zip into Gen1Recomp.
2. Use the mod import option to select Cobblemon493Pack.zip when requested.
3. Enable CobblemonGen1 and play.

The external pack has to match the mod generated in the same build. If you rebuild the pack, use the CobblemonGen1.zip generated with it too.

## Source files, rights, and local-use notice

This project is an independent compatibility/conversion tool. It is not affiliated with or endorsed by Cobblemon, CCC, Modrinth, Mojang/Microsoft, Nintendo, Creatures Inc., GAME FREAK, or The Pokémon Company.

This repository does not bundle the Cobblemon 1.8.1 or CCC 2.1 source packages. Users must obtain required source files themselves from their official distribution pages and are responsible for complying with the licenses and terms that apply to those files. The builder processes user-selected files locally in the browser; it does not scrape Modrinth/CurseForge or automatically download the required source packages.

The generated compatibility pack may contain converted or extracted material from source files selected by the user. Generation does not grant additional rights to redistribute that material. Do not publish, sell, or redistribute generated packs unless you have the rights or permission required by the applicable licenses and rights holders. Credits are acknowledgements and do not replace permission or license compliance.

Pokémon and related names/characters are trademarks and/or copyrighted works of their respective owners. This notice is informational and is not legal advice.
