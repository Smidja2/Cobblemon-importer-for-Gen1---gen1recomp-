CobblemonGen1

Cobblemon models and animations for the Gen1 recomp.

This build uses Cobblemon 1.8.1 + CCC 2.1 as external imports. The builder creates Cobblemon493Pack.zip so models, textures, rigs and animations for #001-493 are available for expanded-dex setups. Models and ecology accept #001-493 when those species exist in the active game/mod setup; unavailable species are ignored by the game data.

Battle:
- Keeps the Gen1 Cobblemon 3D battle integration.
- Uses the authored Cobblemon battle animations where available.
- Pokemon use their authored faint animation instead of simply disappearing at HP 0.
- Cry and attack animation support are kept.
- This does not use the heavily modified Gen2 battle presenter.

Overworld:
- Ground ecology.
- Flying ecology.
- Water ecology.
- Followers.
- Toon rendering support.
- Door/cave/warp follower fix: followers reset at the trainer when entering a real warp so they do not trail into black/out-of-map space.
- Seamless route connections keep the follower formation instead of treating every map change like a door warp.

Files needed to build:
1. Cobblemon 1.8.1 for Minecraft 1.21.1 / Fabric.
2. CCC 2.1 for Minecraft 1.21.1 / Data Pack. Download it as a .zip.

Open the HTML builder, select both files, then press BUILD.

The builder creates:
- Cobblemon493Pack.zip
- CobblemonGen1.zip

Install:
1. Import CobblemonGen1.zip into Gen1Recomp.
2. Use the mod import option to select Cobblemon493Pack.zip when requested.
3. Enable CobblemonGen1 and play.

The external pack has to match the mod generated in the same build. If you rebuild the pack, use the CobblemonGen1.zip generated with it too.
