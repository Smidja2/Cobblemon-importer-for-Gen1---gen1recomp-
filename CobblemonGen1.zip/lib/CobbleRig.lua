local V=...
local R={};R.__index=R
local Voxel3D=V.Voxel3D
local FORMAT=(Voxel3D and Voxel3D.FORMAT) or {{'VertexPosition','float',3},{'VertexTexCoord','float',2},{'VertexShade','float',1}}
local pi=math.pi
local function rad(d)return d*pi/180 end
local function mm(a,b)local r={}for i=0,3 do for j=0,3 do local q=0 for k=0,3 do q=q+a[i*4+k+1]*b[k*4+j+1]end r[i*4+j+1]=q end end return r end
local function T(x,y,z)return{1,0,0,x,0,1,0,y,0,0,1,z,0,0,0,1}end
local function S(x,y,z)return{x,0,0,0,0,y,0,0,0,0,z,0,0,0,0,1}end
local function RX(a)local c,s=math.cos(a),math.sin(a);return{1,0,0,0,0,c,-s,0,0,s,c,0,0,0,0,1}end
local function RY(a)local c,s=math.cos(a),math.sin(a);return{c,0,s,0,0,1,0,0,-s,0,c,0,0,0,0,1}end
local function RZ(a)local c,s=math.cos(a),math.sin(a);return{c,-s,0,0,s,c,0,0,0,0,1,0,0,0,0,1}end
local function tr(m,x,y,z)return m[1]*x+m[2]*y+m[3]*z+m[4],m[5]*x+m[6]*y+m[7]*z+m[8],m[9]*x+m[10]*y+m[11]*z+m[12]end
local evalCache={}
local function dsin(x)return math.sin(rad(x))end
local function dcos(x)return math.cos(rad(x))end
local function dtan(x)return math.tan(rad(x))end
local function clamp(x,a,b)return math.max(a,math.min(b,x))end

-- Compile Molang-style animation expressions as ordinary Lua functions whose
-- required values are explicit parameters. This avoids relying on setfenv or
-- Lua-version-specific load environments inside Gen1Recomp.
local function expr(x,t)
 if type(x)=='number'then return x end
 if type(x)~='string'then return 0 end

 local f=evalCache[x]
 if f==nil then
  local s=x:gsub('q%.anim_time','t'):gsub('query%.anim_time','t')
  s=s:gsub('Math%.Sin','dsin'):gsub('math%.sin','dsin'):gsub('Math%.sin','dsin'):gsub('math%.Sin','dsin')
  s=s:gsub('Math%.Cos','dcos'):gsub('math%.cos','dcos'):gsub('Math%.cos','dcos'):gsub('math%.Cos','dcos')
  s=s:gsub('Math%.Tan','dtan'):gsub('math%.tan','dtan'):gsub('Math%.tan','dtan'):gsub('math%.Tan','dtan')
  s=s:gsub('Math%.Abs','math.abs'):gsub('Math%.abs','math.abs')
  s=s:gsub('Math%.Min','math.min'):gsub('Math%.min','math.min')
  s=s:gsub('Math%.Max','math.max'):gsub('Math%.max','math.max')
  s=s:gsub('Math%.Clamp','clamp'):gsub('Math%.clamp','clamp')

  local src='return function(t,dsin,dcos,dtan,math,clamp) return '..s..' end'
  local chunk

  if type(loadstring)=='function' then
   chunk=loadstring(src)
  elseif type(load)=='function' then
   local ok,fn=pcall(load,src,'=(cobble_expr)')
   if ok then chunk=fn end
  end

  if chunk then
   local ok,fn=pcall(chunk)
   if ok and type(fn)=='function' then f=fn end
  end

  if not f then f=false end
  evalCache[x]=f
 end

 if not f then return tonumber(x) or 0 end
 local ok,v=pcall(f,t,dsin,dcos,dtan,math,clamp)
 return ok and tonumber(v) or 0
end
local function vec(v,t)if type(v)=='number'or type(v)=='string'then local q=expr(v,t);return q,q,q end;if type(v)=='table'then return expr(v[1]or 0,t),expr(v[2]or 0,t),expr(v[3]or 0,t)end;return 0,0,0 end
local function kval(k,w,t)if type(k)=='table'and(k.pre or k.post)then return vec(k[w]or k.post or k.pre,t)end;return vec(k,t)end
local function sample(ch,t)
 if ch==nil then return 0,0,0 end
 if type(ch)~='table' or ch[1]~=nil then return vec(ch,t) end

 local ks={}
 for k,v in pairs(ch) do
  local n=tonumber(k)
  if n then ks[#ks+1]={n,v} end
 end
 table.sort(ks,function(a,b)return a[1]<b[1]end)

 if #ks==0 then return 0,0,0 end
 if t<=ks[1][1] then return kval(ks[1][2],'pre',t) end
 if t>=ks[#ks][1] then return kval(ks[#ks][2],'post',t) end

 local i=1
 while i<#ks and t>ks[i+1][1] do i=i+1 end
 local a,b=ks[i],ks[i+1]
 local u=(t-a[1])/(b[1]-a[1])

 local ax,ay,az=kval(a[2],'post',t)
 local bx,by,bz=kval(b[2],'pre',t)
 local mode=(type(b[2])=='table' and b[2].lerp_mode)
        or (type(a[2])=='table' and a[2].lerp_mode)
        or 'linear'

 if mode=='catmullrom' then
  local p0=ks[math.max(1,i-1)][2]
  local p3=ks[math.min(#ks,i+2)][2]
  local x0,y0,z0=kval(p0,'post',t)
  local x3,y3,z3=kval(p3,'pre',t)
  local function cr(p0,p1,p2,p3,q)
   return .5*((2*p1)+(-p0+p2)*q+(2*p0-5*p1+4*p2-p3)*q*q+(-p0+3*p1-3*p2+p3)*q*q*q)
  end
  return cr(x0,ax,bx,x3,u),cr(y0,ay,by,y3,u),cr(z0,az,bz,z3,u)
 end

 return ax+(bx-ax)*u,ay+(by-ay)*u,az+(bz-az)*u
end
local function dur(a)if a._preview_duration then return a._preview_duration end;if type(a.animation_length)=='number'then return a.animation_length end;local m=0 for _,b in pairs(a.bones or{})do for _,n in ipairs({'rotation','position','scale'})do local c=b[n];if type(c)=='table'and c[1]==nil then for k in pairs(c)do local q=tonumber(k);if q and q>m then m=q end end end end end;return m end
local function atime(a,t)if a._preview_duration then if t>=a._preview_duration then return a._source_duration or a.animation_length or 0 end;return(a._preview_offset or 0)+t*(a._preview_rate or 1)end;local d=dur(a);if a.loop==true and d>0 then return t%d elseif d>0 and t>d then return d else return t end end
local function childOf(D,bn)local bi=D._bi[bn];if not bi then return nil end;for _,b in ipairs(D.bones)do if b.parent==bi and not b.name:find('locator',1,true)then return b.name end end end
local function pose(D,state,t)
 local st=D.states[state]or D.states.stand or{clips={},proc={},vis={},parts={}};local pos,rot,sca={},{},{};for i=1,#D.bones do pos[i]={0,0,0};rot[i]={0,0,0};sca[i]={1,1,1}end
 for bn,x in pairs(st.parts or{})do local bi=D._bi[bn];if bi then if x.position then local a,b,c=vec(x.position,t);pos[bi][1]=pos[bi][1]+a;pos[bi][2]=pos[bi][2]-b;pos[bi][3]=pos[bi][3]+c end;if x.rotation then local a,b,c=vec(x.rotation,t);rot[bi][1]=rot[bi][1]+a;rot[bi][2]=rot[bi][2]+b;rot[bi][3]=rot[bi][3]+c end;if x.scale then local a,b,c=vec(x.scale,t);sca[bi][1]=sca[bi][1]*a;sca[bi][2]=sca[bi][2]*b;sca[bi][3]=sca[bi][3]*c end end end
 for _,cn in ipairs(st.clips or{})do local a=D.anims[cn];if a then local tt=atime(a,t);for bn,ch in pairs(a.bones or{})do local bi=D._bi[bn];if bi then if ch.position then local x,y,z=sample(ch.position,tt);pos[bi][1]=pos[bi][1]+x;pos[bi][2]=pos[bi][2]-y;pos[bi][3]=pos[bi][3]+z end;if ch.rotation then local x,y,z=sample(ch.rotation,tt);rot[bi][1]=rot[bi][1]+x;rot[bi][2]=rot[bi][2]+y;rot[bi][3]=rot[bi][3]+z end;if ch.scale then local x,y,z=sample(ch.scale,tt);sca[bi][1]=sca[bi][1]*x;sca[bi][2]=sca[bi][2]*y;sca[bi][3]=sca[bi][3]*z end end end end end
 local function add(bn,axis,r)local bi=D._bi[bn];if not bi then return end;local q=r*180/pi;if axis=='x'then rot[bi][1]=rot[bi][1]+q elseif axis=='y'then rot[bi][2]=rot[bi][2]+q else rot[bi][3]=rot[bi][3]+q end end
 for _,pr in ipairs(st.proc or{})do
  if pr.type=='sine_wing_flap'then
   local p=tonumber(pr.period)or.9
   local a=tonumber(pr.amplitude)or.9
   if math.abs(p)<.0001 then p=.0001 end
   local q=(tonumber(pr.offset)or 0)+math.sin((2*pi/p)*t)*a
   local b=pr.bones or{}
   if b[1] then add(b[1],pr.axis or'y',q) end
   if b[2] then add(b[2],pr.axis or'y',-q) end

  elseif pr.type=='vertical_hop'then
   local bi=D._bi[pr.bone]
   if bi then pos[bi][2]=pos[bi][2]+math.abs(math.sin(t*pi/(pr.period or.55)))*(pr.height or.55)end

  elseif pr.type=='whole_body_shuffle'then
   local bi=D._bi[pr.bone]
   if bi then
    local sp=pr.speed or 7
    pos[bi][2]=pos[bi][2]+math.abs(math.sin(t*sp))*(pr.height or.1)
    rot[bi][1]=rot[bi][1]+math.sin(t*sp)*(pr.amount or 2.2)
   end

  elseif pr.type=='static_rotate'then
   local bi=D._bi[pr.bone]
   if bi then
    rot[bi][1]=rot[bi][1]+(pr.x or 0)
    rot[bi][2]=rot[bi][2]+(pr.y or 0)
    rot[bi][3]=rot[bi][3]+(pr.z or 0)
   end

  elseif pr.type=='float_bob'then
   local bi=D._bi[pr.bone or'body']
   if bi then
    local per=tonumber(pr.period)or 2.4
    local h=tonumber(pr.height)or.8
    pos[bi][2]=pos[bi][2]+math.sin(t*2*pi/per)*h
   end

  elseif pr.type=='biped_walk'then
   local per=tonumber(pr.period)or.6662
   local amp=tonumber(pr.amplitude)or 1.4
   local b=pr.bones or{}
   local sw=t*6.0
   local amt=tonumber(pr.limbAmount)or.72
   if b[1] then add(b[1],'x',math.cos(sw*per)*amp*amt) end
   if b[2] then add(b[2],'x',math.cos(sw*per+pi)*amp*amt) end

  elseif pr.type=='quadruped_walk'then
   local per=tonumber(pr.period)or.6662
   local amp=tonumber(pr.amplitude)or 1.4
   local b=pr.bones or{}
   local sw=t*6.0
   local amt=tonumber(pr.limbAmount)or.72
   if b[1] then add(b[1],'x',math.cos(sw*per)*amp*amt) end
   if b[2] then add(b[2],'x',math.cos(sw*per+pi)*amp*amt) end
   if b[3] then add(b[3],'x',math.cos(sw*per+pi)*amp*amt) end
   if b[4] then add(b[4],'x',math.cos(sw*per)*amp*amt) end

  elseif pr.type=='bimanual_swing'then
   local per=tonumber(pr.period)or.6662
   local amp=tonumber(pr.amplitude)or 1.4
   local b=pr.bones or{}
   local sw=t*6.0
   local amt=tonumber(pr.limbAmount)or.72
   if b[1] then add(b[1],'x',math.cos(sw*per)*amp*amt) end
   if b[2] then add(b[2],'x',math.cos(sw*per+pi)*amp*amt) end

  elseif pr.type=='pitch_tilt'then
   -- Neutral pitch in the overworld. The authored air_fly clip still animates.

  elseif pr.type=='hold_clip_pose'then
   if t>=(tonumber(pr.start)or 0) then
    local a=D.anims[pr.clip]
    if a then
     local tt=tonumber(pr.time)or 0
     for bn,ch in pairs(a.bones or{})do
      local bi=D._bi[bn]
      if bi then
       if ch.position then local x,y,z=sample(ch.position,tt);pos[bi][1]=pos[bi][1]+x;pos[bi][2]=pos[bi][2]-y;pos[bi][3]=pos[bi][3]+z end
       if ch.rotation then local x,y,z=sample(ch.rotation,tt);rot[bi][1]=rot[bi][1]+x;rot[bi][2]=rot[bi][2]+y;rot[bi][3]=rot[bi][3]+z end
       if ch.scale then local x,y,z=sample(ch.scale,tt);sca[bi][1]=sca[bi][1]*x;sca[bi][2]=sca[bi][2]*y;sca[bi][3]=sca[bi][3]*z end
      end
     end
    end
   end

  elseif pr.type=='procedural_faint'then
   local d=tonumber(pr.duration)or 1.05
   local u=math.max(0,math.min(1,t/d))
   -- ease-out collapse: quick loss of strength, then settle.
   local e=1-(1-u)*(1-u)
   local function rbone(bn,x,y,z)
    local bi=bn and D._bi[bn]
    if bi then rot[bi][1]=rot[bi][1]+(x or 0)*e;rot[bi][2]=rot[bi][2]+(y or 0)*e;rot[bi][3]=rot[bi][3]+(z or 0)*e end
   end
   local function pbone(bn,x,y,z)
    local bi=bn and D._bi[bn]
    if bi then pos[bi][1]=pos[bi][1]+(x or 0)*e;pos[bi][2]=pos[bi][2]+(y or 0)*e;pos[bi][3]=pos[bi][3]+(z or 0)*e end
   end
   if pr.kind=='biped' then
    -- Knees give way, hips/body lower, torso/head droop forward.
    local ls=pr.legs or{}
    if ls[1] then rbone(ls[1],38,0,0) end
    if ls[2] then rbone(ls[2],38,0,0) end
    pbone(pr.root,0,-.55,0)
    rbone(pr.body,18,0,0)
    rbone(pr.head,28,0,0)
   elseif pr.kind=='quadruped' then
    -- All four legs fold and the chest/hips settle toward the floor.
    local fs=pr.front or{};local bs=pr.back or{}
    for _,bn in ipairs(fs)do rbone(bn,30,0,0) end
    for _,bn in ipairs(bs)do rbone(bn,-25,0,0) end
    pbone(pr.root,0,-.42,0)
    rbone(pr.body,10,0,0)
    rbone(pr.head,30,0,0)
   else
    -- Floating / legless species (Geodude-style): arms go limp, body drops,
    -- makes one tiny settling bounce, then holds the down/closed-eye pose.
    local as=pr.arms or{}
    if as[1] then rbone(as[1],0,0,55) end
    if as[2] then rbone(as[2],0,0,-55) end
    rbone(pr.head,20,0,0)
    local drop=-.78*e
    local bounce=0
    if u>.62 then
      local q=(u-.62)/.38
      bounce=math.sin(q*pi*2)*.10*(1-q)
    end
    local bi=D._bi[pr.root]
    if bi then pos[bi][2]=pos[bi][2]+drop+bounce end
   end

  elseif pr.type=='look'then
   local bi=D._bi[pr.bone]
   if bi then
    local pm=tonumber(pr.pitchMultiplier)or 1
    local ym=tonumber(pr.yawMultiplier)or 1
    local maxP=tonumber(pr.maxPitch)or 70
    local minP=tonumber(pr.minPitch)or -45
    local maxY=tonumber(pr.maxYaw)or 45
    local minY=tonumber(pr.minYaw)or -45
    local targetP=math.sin(t*.47)*9
    local targetY=math.sin(t*.31)*18
    if targetP<minP then targetP=minP elseif targetP>maxP then targetP=maxP end
    if targetY<minY then targetY=minY elseif targetY>maxY then targetY=maxY end
    rot[bi][1]=rot[bi][1]+targetP*pm
    rot[bi][2]=rot[bi][2]+targetY*ym
   end
  end
 end

 -- Source quirks/blink layered over the base state. This makes a stationary
 -- Pokemon continue to look alive instead of freezing on the first idle pose.
 for _,cn in ipairs(st.quirks or{})do
  local a=D.anims[cn]
  if a then
   local d=dur(a)
   if d>0 then
    local cycle=5+d
    local qt=t%cycle
    if qt<d then
     for bn,ch in pairs(a.bones or{})do
      local bi=D._bi[bn]
      if bi then
       if ch.position then
        local x,y,z=sample(ch.position,qt)
        pos[bi][1]=pos[bi][1]+x;pos[bi][2]=pos[bi][2]-y;pos[bi][3]=pos[bi][3]+z
       end
       if ch.rotation then
        local x,y,z=sample(ch.rotation,qt)
        rot[bi][1]=rot[bi][1]+x;rot[bi][2]=rot[bi][2]+y;rot[bi][3]=rot[bi][3]+z
       end
       if ch.scale then
        local x,y,z=sample(ch.scale,qt)
        sca[bi][1]=sca[bi][1]*x;sca[bi][2]=sca[bi][2]*y;sca[bi][3]=sca[bi][3]*z
       end
      end
     end
    end
   end
  end
 end
 local hidden={};for i,b in ipairs(D.bones)do local v=(st.vis or{})[b.name];if v==false then hidden[i]=true elseif b.parent and b.parent>0 and hidden[b.parent]then hidden[i]=true end end
 return pos,rot,sca,hidden
end
local function toonEnabled()
 local api=rawget(_G,'COBBLEMON_API')
 if api and type(api.outlineEnabled)=='function' then
  local ok,v=pcall(api.outlineEnabled);if ok then return v~=false end
 end
 return false
end
local function faceNormal(a,b,c)
 local ux,uy,uz=b[1]-a[1],b[2]-a[2],b[3]-a[3]
 local vx,vy,vz=c[1]-a[1],c[2]-a[2],c[3]-a[3]
 local nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
 local L=math.sqrt(nx*nx+ny*ny+nz*nz)
 if L>0 then return nx/L,ny/L,nz/L end
 return 0,1,0
end
local function toonShade(nx,ny,nz)
 local raw=0.7725+0.06*nx+0.225*ny+0.11*nz
 if raw<0.76 then return 0.52 elseif raw<0.90 then return 0.76 else return 1.00 end
end
function R.new(model)
 local self=setmetatable({model=model,state='stand',time=0,parts={},work={}},R)
 local rows={}for i,v in ipairs(model.verts)do rows[i]={v[1],-v[2],v[3],v[4],v[5],1}end
 local ok,m=pcall(love.graphics.newMesh,FORMAT,rows,'triangles','dynamic');if not ok or not m then return nil end
 -- Cobblemon gameplay renderers draw actor.rig.parts directly and skip any part
 -- without BOTH mesh and texture. Stadium follows the same contract.
 if model.texture and m.setTexture then pcall(m.setTexture,m,model.texture) end
 local om=nil
 local okO,o=pcall(love.graphics.newMesh,FORMAT,rows,'triangles','dynamic');if okO then om=o end
 if om and model.texture and om.setTexture then pcall(om.setTexture,om,model.texture) end
 self.mesh=m;self.outlineMesh=om;self.parts[1]={mesh=m,outlineMesh=om,texture=model.texture};self:skin(0);return self
end
function R:setState(s)self.state=s;self.time=0;return self end
function R:duration()local st=self.model.states[self.state];local m=0;for _,cn in ipairs(st and st.clips or{})do local a=self.model.anims[cn];if a then m=math.max(m,dur(a))end end;return m end
function R:skin(t)
 if self._actor and self._actor.time~=nil then
  t=self._actor.time
 end
 self.time=t or self.time
 local D=self.model
 local pos,ar,sc,hidden=pose(D,self.state,self.time)
 local wm={}
 local minx,miny,minz=1e9,1e9,1e9
 local maxx,maxy,maxz=-1e9,-1e9,-1e9
 local contactMinY=1e9
 local hasContact=false

 for i,b in ipairs(D.bones)do
  local rr={b.r[1]+ar[i][1],b.r[2]+ar[i][2],b.r[3]+ar[i][3]}
  local lm=T(b.t[1]+pos[i][1],b.t[2]+pos[i][2],b.t[3]+pos[i][3])
  lm=mm(lm,RZ(rad(rr[3])));lm=mm(lm,RY(rad(rr[2])));lm=mm(lm,RX(rad(rr[1])))
  lm=mm(lm,S(sc[i][1],sc[i][2],sc[i][3]))
  wm[i]=(b.parent and b.parent>0)and mm(wm[b.parent],lm)or lm
 end

 for i,v in ipairs(D.verts)do
  local o=self.work[i]or{0,0,0,0,0,1};self.work[i]=o
  if hidden[v[6]]then
   o[1],o[2],o[3]=9999,9999,9999
  else
   local x,y,z=tr(wm[v[6]],v[1],v[2],v[3])
   local yy=-y
   o[1],o[2],o[3]=x,yy,z
   if x<minx then minx=x end;if x>maxx then maxx=x end
   if yy<miny then miny=yy end;if yy>maxy then maxy=yy end
   if z<minz then minz=z end;if z>maxz then maxz=z end

   -- Prefer vertices attached to anatomical ground-contact bones for the
   -- standing anchor. Using the absolute mesh minimum can anchor a bird by
   -- a wing/tail instead of by its feet.
   local bone=D.bones[v[6]]
   local bn=bone and string.lower(bone.name or "") or ""
   if bn:find("foot",1,true) or bn:find("toe",1,true)
      or bn:find("claw",1,true) or bn:find("paw",1,true)
      or bn:find("hoof",1,true) or bn:find("talon",1,true) then
    hasContact=true
    if yy<contactMinY then contactMinY=yy end
   end
  end
  o[4],o[5],o[6]=v[4],v[5],1
 end

 local toon=toonEnabled()
 local outline=self._outlineWork or {};self._outlineWork=outline
 local inflate=math.max(.001,((maxy>miny and miny<1e8) and (maxy-miny) or 1)*0.035)
 for i=1,#self.work,3 do
  local a,b,c=self.work[i],self.work[i+1],self.work[i+2]
  if c then
   local hiddenTri=(a[1]>9000 or b[1]>9000 or c[1]>9000)
   local nx,ny,nz=0,1,0
   if not hiddenTri then nx,ny,nz=faceNormal(a,b,c) end
   local shade=toon and toonShade(nx,ny,nz) or 1
   a[6],b[6],c[6]=shade,shade,shade
   for j=i,i+2 do
    local q=self.work[j];local z=outline[j] or {0,0,0,0,0,1};outline[j]=z
    if hiddenTri then z[1],z[2],z[3]=9999,9999,9999 else z[1],z[2],z[3]=q[1]+nx*inflate,q[2]+ny*inflate,q[3]+nz*inflate end
    z[4],z[5],z[6]=q[4],q[5],1
   end
  end
 end
 pcall(self.mesh.setVertices,self.mesh,self.work)
 if self.outlineMesh then pcall(self.outlineMesh.setVertices,self.outlineMesh,outline) end

 if minx<1e8 then
  self.lo,self.hi=miny,maxy
  if D.baseFloor==nil then
   local anchor=(hasContact and contactMinY<1e8) and contactMinY or miny
   D.baseFloor=anchor
   D.floor=anchor
  end
  D.height=math.max(.001,maxy-miny)
 end

 if D._textureFrames and #D._textureFrames>0 then
  local fi=math.floor(self.time*(D.textureFPS or 10))%#D._textureFrames+1
  self.parts[1].texture=D._textureFrames[fi]
 end
 return true
end
function R:pose(_,frame,_)return self:skin((frame or 0)/30)end
function R:textures()return true end
function R:anchor()return true end
function R:release()if self.mesh and self.mesh.release then pcall(self.mesh.release,self.mesh)end;if self.outlineMesh and self.outlineMesh.release then pcall(self.outlineMesh.release,self.outlineMesh)end;self.parts={}end
function R:drawPackets(mat,phase,owner,seq)local out={};local n=seq or 1;for _,p in ipairs(self.parts)do out[#out+1]={schemaVersion=1,cacheKey='cobble:'..tostring(self.model.species)..':'..n,kind='mesh',owner=owner or'cobblemon.main',phase=phase,sequence=n,sortKey=('cobble:%03d:%04d'):format(self.model.species,n),material='companion.default',mesh=p.mesh,model=mat};n=n+1 end;return out,n end
return R
