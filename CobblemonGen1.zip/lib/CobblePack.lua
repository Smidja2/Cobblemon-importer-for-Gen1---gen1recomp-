local V=...
local P={cache={},textures={}}
local IMPORT_ID='cobblemon_mesh_texture_zip'
local zipIndex=nil
local function u16(s,i) local a,b=s:byte(i,i+1); return a+b*256 end
local function u32(s,i) local a,b,c,d=s:byte(i,i+3); return a+b*256+c*65536+d*16777216 end
local function buildZipIndex()
  if zipIndex then return zipIndex end
  zipIndex={}
  if not (V.mod and V.mod.imports and type(V.mod.imports.info)=='function') then return zipIndex end
  local info=V.mod.imports:info(IMPORT_ID); if not info then return zipIndex end
  local size=tonumber(info.size or info.length or 0) or 0
  if size<=0 then return zipIndex end
  local tailN=math.min(size,66000); local tail=V.mod.imports:read(IMPORT_ID,size-tailN,tailN)
  if not tail then return zipIndex end
  local eocd=nil
  for i=#tail-21,1,-1 do if tail:sub(i,i+3)=='PK\005\006' then eocd=i;break end end
  if not eocd then return zipIndex end
  local count=u16(tail,eocd+10); local cdOff=u32(tail,eocd+16); local off=cdOff
  for _=1,count do
    local h=V.mod.imports:read(IMPORT_ID,off,46); if not h or h:sub(1,4)~='PK\001\002' then break end
    local method=u16(h,11); local csize=u32(h,21); local usize=u32(h,25); local nl=u16(h,29); local xl=u16(h,31); local cl=u16(h,33); local lo=u32(h,43)
    local name=V.mod.imports:read(IMPORT_ID,off+46,nl)
    if name then zipIndex[name]={method=method,csize=csize,usize=usize,localOff=lo} end
    off=off+46+nl+xl+cl
  end
  return zipIndex
end
local function zipRead(path)
  local e=buildZipIndex()[path]; if not e or e.method~=0 then return nil end
  local h=V.mod.imports:read(IMPORT_ID,e.localOff,30); if not h or h:sub(1,4)~='PK\003\004' then return nil end
  local nl=u16(h,27); local xl=u16(h,29); return V.mod.imports:read(IMPORT_ID,e.localOff+30+nl+xl,e.csize)
end
local function loadPackLua(rel)
  local b=zipRead(rel); if not b then return nil,'missing imported '..rel end
  local f,e=load(b,'@import/'..rel); if not f then return nil,e end
  local ok,v=pcall(f); if not ok then return nil,v end; return v
end

local function loadLua(rel)
  local s=V.mod:read(rel)
  if not s then return nil,'missing '..rel end
  local f,e=load(s,'@'..V.mod.path..'/'..rel)
  if not f then return nil,e end
  local ok,v=pcall(f)
  if not ok then return nil,v end
  return v
end

local function image(rel)
  if P.textures[rel] then return P.textures[rel] end
  local bytes=zipRead(rel) or V.mod:read(rel); if not bytes then return nil end
  local ok,fd=pcall(love.filesystem.newFileData,bytes,rel)
  if not ok then return nil end
  local ok2,img=pcall(love.graphics.newImage,fd)
  if not ok2 then return nil end
  img:setFilter('nearest','nearest'); img:setWrap('clamp','clamp')
  P.textures[rel]=img
  return img
end

local function cloneState(st,label)
  st=st or {clips={},proc={},vis={},parts={},quirks={}}
  local o={label=label or st.label,clips={},proc={},vis={},parts={},quirks={}}
  for _,v in ipairs(st.clips or{}) do o.clips[#o.clips+1]=v end
  for _,v in ipairs(st.proc or{}) do local q={};for k,x in pairs(v)do q[k]=x end;o.proc[#o.proc+1]=q end
  for k,v in pairs(st.vis or{}) do o.vis[k]=v end
  for k,v in pairs(st.parts or{}) do o.parts[k]=v end
  for _,v in ipairs(st.quirks or{}) do o.quirks[#o.quirks+1]=v end
  return o
end
local function cleanGait(st)
  local q={};for _,v in ipairs(st.proc or{}) do if v.type~='biped_walk' and v.type~='quadruped_walk' and v.type~='vertical_hop' and v.type~='whole_body_shuffle' then q[#q+1]=v end end;st.proc=q;return st
end

local generic=assert(loadLua('generic_attacks.lua'))
local quick={19,20,25,26,52,53,123,133,135}
local aerial={16,17,18,21,22,41,42,83,84,85,142,144,145,146}
local flame={4,5,37,38,58,59,77,78,126,136}
local close={56,57,66,67,68,106,107}
local slam={3,31,34,76,80,89,95,112,113,115,128,130,131,143}
local rough={35,36,39,40}
local moveByDex={}
local function put(m,a)for _,d in ipairs(a)do moveByDex[d]=m end end
put('quickattack',quick);put('aerialace',aerial);put('flamecharge',flame);put('closecombat',close);put('bodyslam',slam);put('playrough',rough)

local function rootName(D)
  local roots={}
  for i,b in ipairs(D.bones or{}) do if not b.parent or b.parent<=0 then roots[#roots+1]=b.name end end
  return roots[1] or (D.bones and D.bones[1] and D.bones[1].name) or 'body'
end

local function addGeneric(D,move)
  local src=generic[move]; if not src then return nil end
  local root=rootName(D)
  local a={animation_length=src.animation_length,loop=false,bones={}}
  for bn,ch in pairs(src.bones or{}) do
    local out={}
    for k,v in pairs(ch) do
      if not ((move=='quickattack' or move=='aerialace' or move=='closecombat' or move=='playrough') and k=='scale') then out[k]=v end
    end
    a.bones[(bn=='root_part') and root or bn]=out
  end
  local prof={tackle={1.05,.62},flamecharge={1.05,.62},quickattack={1.00,.50},aerialace={.45,.78},bodyslam={0,.78},closecombat={0,.82},playrough={0,.72}}
  local pp=prof[move]
  if pp then a._preview_offset=pp[1];a._preview_rate=pp[2];a._source_duration=tonumber(a.animation_length)or 1;a._preview_duration=math.max(.45,(a._source_duration-a._preview_offset)/a._preview_rate) end
  local key='cr_generic_'..move;D.anims[key]=a;return key
end

local function applyOverrides(dex,D)
  D.states=D.states or{};D.anims=D.anims or{}
  local root=rootName(D)

  -- Native Cobblemon capability states. Generated state tables cover the
  -- common viewer poses; expose every useful authored clip directly when present.
  local function baseStateFor(key)
    -- Do not rebuild locomotion states from STAND. The generated Cobblemon
    -- poser states carry critical transformed-part visibility (especially
    -- open-vs-closed wing meshes) and pose-specific procedural data.
    if D.states[key] then return cloneState(D.states[key]) end
    if key=="airidle" and D.states.fly then return cloneState(D.states.fly) end
    if key=="run" and D.states.walk then return cloneState(D.states.walk) end
    if (key=="wateridle" or key=="waterswim" or key=="surfaceidle" or key=="surfaceswim")
       and D.states.surf then return cloneState(D.states.surf) end
    return cloneState(D.states.stand)
  end

  local function clipState(key,label,clip)
    if D.anims[clip] then
      local base=baseStateFor(key)
      base.label=label or key
      base.clips={clip}
      base.proc=base.proc or {}
      base.quirks=base.quirks or {}
      D.states[key]=base
    end
  end
  local cryClip=D.anims.battle_cry and 'battle_cry' or (D.anims.cry and 'cry' or nil)
  clipState('cry','cry',cryClip or 'cry')

  -- Battle cry overlay: keep the normal standing/idle pose running and layer
  -- only the authored cry keys on top. Many Cobblemon cry clips key only a
  -- handful of bones; playing them alone leaves every unkeyed bone in bind
  -- pose (the visible T-pose problem).
  if cryClip and D.anims[cryClip] then
    local base=cloneState(D.states.stand,'idle + cry')
    base.clips=base.clips or {}
    base.clips[#base.clips+1]=cryClip
    base._overlayClip=cryClip
    base._oneShotDuration=tonumber(D.anims[cryClip].animation_length) or .8
    D.states.cryoverlay=base
  end
  clipState('physical','physical','physical')
  clipState('special','special','special')
  clipState('status','status','status')

  -- Faint: prefer the normal authored clip, but use the other real Cobblemon
  -- faint clips when a species does not provide plain `faint`.  These are
  -- actual bone animations from the source data, not synthetic fall/sink FX.
  local faintClip=nil
  local faintPriority={
    'faint',
    'battle_faint',
    'ground_faint',
    'water_faint',
    'true faint',
    'faint2',
    'faint_WIP',
    'battle_faint_WIP',
    'ground_faint_WIP',
    'faint_old',
  }
  for _,clip in ipairs(faintPriority) do
    if D.anims[clip] and D.anims[clip].bones and next(D.anims[clip].bones)~=nil then
      faintClip=clip
      break
    end
  end
  if faintClip then
    clipState('faint','faint',faintClip)
    D.states.faint._sourceFaintClip=faintClip
  else
    -- No authored faint exists for this species. Build a conservative
    -- skeleton-driven collapse from its normal standing pose. This is only a
    -- fallback; authored faint clips above always win.
    local function boneNamesMatching(words)
      local out={}
      for _,b in ipairs(D.bones or {}) do
        local n=string.lower(b.name or '')
        for _,w in ipairs(words) do
          if n:find(w,1,true) and not n:find('locator',1,true) then out[#out+1]=b.name;break end
        end
      end
      return out
    end
    local legs=boneNamesMatching({'leg_','legleft','legright','legleft','leg_right','leg_left','thigh','shin'})
    local arms=boneNamesMatching({'arm_','armleft','armright','forearm'})
    local heads=boneNamesMatching({'head'})
    local head=heads[1] or (D._bi.neck and 'neck' or nil)
    local body=(D._bi.torso and 'torso') or (D._bi.body and 'body') or root
    local front,back={},{}
    for _,bn in ipairs(legs) do
      local n=string.lower(bn)
      if n:find('front',1,true) then front[#front+1]=bn
      elseif n:find('back',1,true) or n:find('rear',1,true) then back[#back+1]=bn end
    end
    local kind
    if #front>=2 and #back>=2 then kind='quadruped'
    elseif #legs>=2 then kind='biped'
    else kind='floating' end
    local f=cloneState(D.states.stand,'procedural faint')
    f.proc=f.proc or {}
    f.proc[#f.proc+1]={type='procedural_faint',kind=kind,root=root,body=body,head=head,legs=legs,front=front,back=back,arms=arms,duration=1.05}
    -- Most Cobblemon models have an authored blink whose first ~0.1 s is the
    -- fully-closed eye pose. Hold that pose through the collapse.
    if D.anims.blink and D.anims.blink.bones and next(D.anims.blink.bones)~=nil then
      f.proc[#f.proc+1]={type='hold_clip_pose',clip='blink',time=.10,start=.18}
    end
    f._oneShotDuration=1.05
    f._proceduralFaint=true
    D.states.faint=f
  end

  clipState('hurt','hurt',D.anims.hurt and 'hurt' or 'recoil')
  clipState('recoil','recoil','recoil')
  clipState('sleep','sleep','sleep')
  clipState('run','run','ground_run')
  clipState('airidle','air idle','air_idle')
  clipState('fly','fly','air_fly')
  clipState('wateridle','water idle','water_idle')
  clipState('waterswim','water swim','water_swim')
  clipState('surfaceidle','surface idle','surfacewater_idle')
  clipState('surfaceswim','surface swim','surfacewater_swim')

  -- Cobblemon bird models commonly contain TWO physical wing sets:
  -- folded/closed wings for ground poses and open wings for flight.
  -- The poser normally toggles these via transformed-part visibility.
  -- Enforce the parent-group visibility too so descendants cannot leak
  -- through when a source pose only specifies individual wing roots.
  local function hasBone(name) return D._bi and D._bi[name]~=nil end
  local function wingMode(st,open)
    if not st then return end
    st.vis=st.vis or {}
    if hasBone("wings_open") then st.vis.wings_open=open end
    if hasBone("wings_closed") then st.vis.wings_closed=not open end
    if hasBone("wing_open_left") then st.vis.wing_open_left=open end
    if hasBone("wing_open_right") then st.vis.wing_open_right=open end
    if hasBone("wing_closed_left") then st.vis.wing_closed_left=not open end
    if hasBone("wing_closed_right") then st.vis.wing_closed_right=not open end
  end

  wingMode(D.states.stand,false)
  wingMode(D.states.walk,false)
  wingMode(D.states.run,false)
  wingMode(D.states.fly,true)
  wingMode(D.states.airidle,true)
  -- authored ground_walk wins; generated state tables already use it for most species.
  if D.anims.ground_walk and D.states.walk then
    D.states.walk.clips={'ground_walk'}
    local q={};for _,pr in ipairs(D.states.walk.proc or{})do if pr.type~='biped_walk' and pr.type~='quadruped_walk' and pr.type~='vertical_hop' and pr.type~='whole_body_shuffle' then q[#q+1]=pr end end;D.states.walk.proc=q
  end
  if dex==19 then local w=cleanGait(cloneState(D.states.stand,'Rattata scurry'));w.proc[#w.proc+1]={type='whole_body_shuffle',bone=root,speed=12,height=.075,amount=1.8};D.states.walk=w end
  if dex==21 or dex==22 then local w=cleanGait(cloneState(D.states.stand,dex==21 and'Spearow hop'or'Fearow hop'));w.proc[#w.proc+1]={type='vertical_hop',bone=root,period=.55,height=.55};D.states.walk=w end
  if dex==53 then local w=cleanGait(cloneState(D.states.stand,'Persian quadruped'));w.proc[#w.proc+1]={type='quadruped_walk',root=root,period=.66,amplitude=1.4,limbAmount=.38,bones={'leg_front_left1','leg_front_right1','leg_back_left1','leg_back_right1'}};D.states.walk=w end
  if dex==58 then local w=cleanGait(cloneState(D.states.stand,'Growlithe quadruped'));w.proc[#w.proc+1]={type='quadruped_walk',root=root,period=.66,amplitude=1.4,limbAmount=.38,bones={'leg_front_left','leg_front_right','leg_back_left','leg_back_right'}};D.states.walk=w end
  if dex==38 then local w=cleanGait(cloneState(D.states.stand,'Ninetales quadruped'));w.proc[#w.proc+1]={type='quadruped_walk',root=root,period=.66,amplitude=1.4,limbAmount=.36,bones={'leg_front_left','leg_front_right','leg_back_left','leg_back_right'}};w.proc[#w.proc+1]={type='static_rotate',bone='tail_middle',x=-22};D.states.walk=w end
  if dex==72 or dex==73 then local w=cloneState(D.states.stand,'water_swim walk');w.clips={'water_swim'};w.proc={{type='float_bob',bone=root,period=1.25,height=.12}};D.states.walk=w end
  if dex>=133 and dex<=136 and D.states.walk then for _,pr in ipairs(D.states.walk.proc or{})do if pr.type=='quadruped_walk'then pr.root=root;pr.limbAmount=.36 end end end
  -- Mew/Mewtwo: source walk only, no artificial preview movement.
  if (dex==150 or dex==151) and D.anims.ground_walk and D.states.walk then D.states.walk.clips={'ground_walk'};local q={};for _,pr in ipairs(D.states.walk.proc or{})do if pr.type~='float_bob' and pr.type~='gentle_sway' and pr.type~='whole_body_shuffle'then q[#q+1]=pr end end;D.states.walk.proc=q end

  local authored=D.states.attack and D.states.attack.clips and D.states.attack.clips[1]
  local authoredOK=authored and authored~='generic_tackle' and D.anims[authored]
  if dex==26 then authoredOK=false end -- avoid Kanto/Alolan tail collision
  if not authoredOK then
    local move=moveByDex[dex] or 'tackle'; local key=addGeneric(D,move)
    local b=cloneState(D.states.stand,'generic '..move); if key then b.clips[#b.clips+1]=key end;D.states.attack=b
  end
  return D
end

function P.load(species)
  species=tonumber(species);if not species or species<1 or species>493 then return nil end
  if P.cache[species] then return P.cache[species] end
  local D,err=loadPackLua(('animations/%03d.lua'):format(species));if not D then return nil,err end
  if species>251 then
    local M,merr=loadPackLua(('mesh/%03d.lua'):format(species));if not M then return nil,merr end
    D.bones=M.bones or {};D.verts=M.verts or {}
  end
  D.species=species;D._bi={};for i,b in ipairs(D.bones or{})do D._bi[b.name]=i end
  applyOverrides(species,D)
  D.texture=image(('textures/%03d.png'):format(species))
  if D.textureFrames and #D.textureFrames>0 then
    D._textureFrames={};for _,rel in ipairs(D.textureFrames)do D._textureFrames[#D._textureFrames+1]=image(rel) end
    if D._textureFrames[1] then D.texture=D._textureFrames[1] end
  end
  P.cache[species]=D;return D
end
function P.available(species)return tonumber(species)and tonumber(species)>=1 and tonumber(species)<=493 end
function P.invalidate()P.cache={} end
return P
